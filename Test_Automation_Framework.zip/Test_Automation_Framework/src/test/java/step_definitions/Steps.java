package step_definitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.Implementation;

public class Steps {

	Implementation implementObject = new Implementation();
	
	@Given("^Iam on valtech\\.com homepage$")
	public void iam_on_valtech_com_homepage() {
		implementObject.openHomepage(); 
	}

	@Then("^I should see the latest news section$")
	public void i_should_see_the_latest_news_section()  {
		implementObject.verifyLatestNews();
	}
	
	@When("^I click the About link$")
	public void i_click_the_About_link()  {
	   implementObject.clickAbout();
	}

	@Then("^I should assert the About heading$")
	public void i_should_assert_the_About_heading()  {
		implementObject.verifyAbout();
	  
	}

	@When("^I click the services link$")
	public void i_click_the_services_link()  {
	    implementObject.clickServices();
	}

	@Then("^I should assert the Services heading$")
	public void i_should_assert_the_Services_heading()  {
	    implementObject.verifyServices();
	}
	
	@When("^I click the work link$")
	public void i_click_the_work_link()  {
	    implementObject.workPage();
	}

	@Then("^I should assert the work heading$")
	public void i_should_assert_the_work_heading()  {
		implementObject.verifyWork();
	}
	
	@When("^I click the Contact link$")
	public void i_click_the_Contact_link() throws InterruptedException  {
	   implementObject.contactPage();
	}

	@Then("^I should know the number of offices$")
	public void i_should_know_the_number_of_offices() throws InterruptedException  {
		implementObject.valtech_offices_Test();
	}
}
