import cucumber.api.java.After;
import cucumber.api.java.Before;
import pageObjects.ParentClass;

public class Hook {
	
	ParentClass parentobject = new ParentClass();
	
	@Before
	public void beforeTest() {
		parentobject.openBrowser();
		
	}
	@After
	public void afterTest() {
		parentobject.closeBrowser();
	}
	
}
