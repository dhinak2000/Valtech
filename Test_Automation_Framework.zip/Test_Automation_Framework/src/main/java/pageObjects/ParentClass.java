package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ParentClass {
	
	static WebDriver driver;
	
	public void openBrowser() {
	
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumDrivers\\chromedriver.exe");	
		driver = new ChromeDriver();	
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
	}
	
	public void closeBrowser() {
		
		driver.close();
		driver.quit();
		
	}
	
}
