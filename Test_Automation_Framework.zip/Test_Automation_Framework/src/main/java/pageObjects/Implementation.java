package pageObjects;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Implementation extends ParentClass {

	public void openHomepage ()
	{
		driver.get("https://www.valtech.com");
		
    }
	
	public void verifyLatestNews ()
	{
		WebElement newsSection = driver.findElement(By.xpath("//*[@id=\"container\"]/div[2]/div[3]/div[1]/header/h2"));
		Assert.assertEquals("LATEST NEWS", newsSection.getText());
	}
	
	public void clickAbout ()
	{
		WebElement aboutPage =  driver.findElement(By.xpath("//*[@id=\"navigationMenuWrapper\"]/div/ul/li[1]/a/span"));
		aboutPage.click();
	}
	
	public void verifyAbout ()
	{
		WebElement title  = driver.findElement(By.tagName("h1"));
		Assert.assertEquals("About", title.getText());
	}

	public void clickServices ()
	{
		WebElement servicesPage =  driver.findElement(By.xpath("//*[@id=\"navigationMenuWrapper\"]/div/ul/li[3]/a/span"));
		servicesPage.click();
	}
	
	public void verifyServices ()
	{
		WebElement title  = driver.findElement(By.tagName("h1"));
		Assert.assertEquals("Services", title.getText());
	}

	public void workPage ()
	{
		WebElement workPage =  driver.findElement(By.xpath("//*[@id=\"navigationMenuWrapper\"]/div/ul/li[2]/a/span"));
		workPage.click();
	}
	
	public void verifyWork ()
	{
		WebElement title  = driver.findElement(By.tagName("h1"));
		Assert.assertEquals("Work", title.getText());
	}

	
	public void contactPage () throws InterruptedException
	{
		WebElement contactUsArea = driver.findElement(By.xpath("//*[@id=\"CTA-form-trigger\"]/div/div/span"));
		
		Actions clickBtn = new Actions(driver);
		clickBtn.moveToElement(contactUsArea).click().perform();

	}	

	public void valtech_offices_Test() throws InterruptedException {
		
		Thread.sleep(2000);
		Select se = new Select(driver.findElement(By.name("Country")));
		
		// Assumption 1: Drop down value "Where are you" is  hard-coded and always present
		// Assumption 2: Drop down value "other" is hard-coded and always present	

		List<WebElement> numberOfOfficesList = se.getOptions();
		int number_of_offices = numberOfOfficesList.size();
		if(number_of_offices > 2) {
			number_of_offices = number_of_offices -2;
		}
		else {
			number_of_offices = 0;
		}
		
		Assert.assertEquals(28, number_of_offices);
		System.out.println("[Number of Valtech offices:" + number_of_offices + "]");
		
	}
}	
